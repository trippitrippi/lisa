# Lisa Word - Database Gallerie d'Arte Giapponesi (Versione Espansa 2025)

## Descrizione

Questa applicazione è la versione aggiornata ed espansa del database di gallerie d'arte giapponesi curato da Lisa Word. Il progetto è nato per aiutare artisti emergenti a trovare opportunità di esposizione in Giappone, fornendo informazioni dettagliate e verificate su gallerie d'arte in tutto il paese.

## Caratteristiche Principali

### 📊 Database Completo
- **203 gallerie originali** verificate dal database iniziale
- **208 nuove gallerie** aggiunte nell'espansione 2025
- **Totale di 411 gallerie** in tutto il Giappone

### 🗺️ Mappa Interattiva
- Visualizzazione geografica di tutte le gallerie
- Filtri per tipo di galleria (originale/espansa)
- Marker colorati per distinguere gallerie originali e nuove
- Finestre informative dettagliate
- Controlli di navigazione e zoom

### 🔍 Sistema di Ricerca e Filtri
- Filtri per città, categoria e tipo di arte
- Ricerca facilitata delle gallerie in base a diversi criteri
- Visualizzazione dettagliata delle informazioni

### 📱 Design Responsivo
- Interfaccia ottimizzata per dispositivi desktop e mobili
- Navigazione intuitiva e facilmente accessibile

### 🔐 Pannello Amministrativo
- Gestione completa delle gallerie (originali ed espanse)
- Verifica automatica degli URL delle gallerie
- Sistema di rimozione gallerie con URL non funzionanti
- Approvazione delle nuove richieste di aggiunta gallerie
- Dashboard con statistiche in tempo reale

### 📧 Sistema di Contatti
- Form di contatto per comunicare con l'amministrazione
- Possibilità di segnalare modifiche o problemi con le gallerie esistenti
- Richiesta di aggiunta di nuove gallerie

## Tecnologie Utilizzate

- **Frontend**: HTML5, CSS3, JavaScript
- **Framework e Librerie**:
  - TailwindCSS per lo styling
  - Chart.js per le visualizzazioni statistiche
  - Google Maps API per la mappa interattiva
- **Storage**: LocalStorage per la persistenza dei dati lato client
- **Verifica URL**: Sistema integrato per la verifica degli URL delle gallerie

## Credenziali Admin Demo

Per accedere all'area amministrativa demo:
- Email: `admin@lisaword.com`
- Password: `Lisa2025Admin!`

## Avvio del Progetto

1. Clone del repository:
   ```
   git clone https://github.com/lisa-word/gallery-database.git
   cd gallery-database
   ```

2. Apertura del file index.html in un browser

## Struttura del Progetto

```
lisa-word-espanso/
├── index.html              # File HTML principale
├── data/                   # Dati delle gallerie
│   ├── galleries_combined.json
│   ├── gallerie_database_iniziale.json
│   └── japanese_galleries_final.json
├── assets/                 # File JavaScript e CSS
│   ├── lisa-word-extended.js
│   ├── map-manager.js
│   └── url-validator.js
└── images/                 # Immagini e icone
    ├── gallery-1.jpg
    ├── gallery-2.jpg
    ├── gallery-3.jpg
    ├── map-marker.png
    └── map-marker-expanded.png
```

## Funzionalità Future

- **Sistema di autenticazione completo** per utenti registrati
- **API pubblica** per l'accesso programmatico ai dati delle gallerie
- **Integrazione social media** per condividere gallerie
- **Sistema di recensioni** per artisti che hanno esposto nelle gallerie
- **App mobile nativa** per iOS e Android

## Contatti

Per supporto o informazioni aggiuntive, contattare: carlogrecoph@gmail.com