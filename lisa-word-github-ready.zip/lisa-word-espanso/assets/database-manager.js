/**
 * Database Manager per Lisa Word
 * Gestisce la persistenza dei dati attraverso localStorage
 */
class DatabaseManager {
    constructor() {
        this.STORAGE_KEYS = {
            ORIGINAL_GALLERIES: 'lisa_word_original_galleries',
            EXPANDED_GALLERIES: 'lisa_word_expanded_galleries', 
            PENDING_GALLERIES: 'lisa_word_pending_galleries',
            LAST_GALLERY_ID: 'lisa_word_last_gallery_id'
        };
        
        // Inizializza il database al primo caricamento
        this.initializeDatabase();
    }
    
    /**
     * Inizializza il database se non esiste già
     */
    initializeDatabase() {
        // Controlla se il database è già stato inizializzato
        if (!localStorage.getItem(this.STORAGE_KEYS.ORIGINAL_GALLERIES) || 
            !localStorage.getItem(this.STORAGE_KEYS.EXPANDED_GALLERIES) ||
            !localStorage.getItem(this.STORAGE_KEYS.PENDING_GALLERIES)) {
            
            console.log('Initializing database from scratch');
            
            // Carica i dati originali dalle variabili globali (prima volta)
            // In un'app reale, questo verrebbe fatto con una richiesta API
            if (typeof originalGalleriesData !== 'undefined' && originalGalleriesData.length > 0) {
                this.saveOriginalGalleries(originalGalleriesData);
            } else {
                this.saveOriginalGalleries([]);
            }
            
            if (typeof expandedGalleriesData !== 'undefined' && expandedGalleriesData.length > 0) {
                this.saveExpandedGalleries(expandedGalleriesData);
            } else {
                this.saveExpandedGalleries([]);
            }
            
            // Inizializza le richieste pendenti come un array vuoto
            this.savePendingGalleries([
                // Aggiungo due gallerie di esempio come pendenti per dimostrare la funzionalità
                {
                    id: 'pending-1',
                    nome: 'Nueva Galería de Arte',
                    nome_jp: '',
                    citta: 'Tokyo',
                    categoria: 'Arte Contemporanea',
                    website: 'https://example.com',
                    indirizzo: '1-2-3 Shibuya, Tokyo',
                    email: 'info@nuevagaleria.com',
                    telefono: '+81 3-1234-5678',
                    descrizione: 'Una nuova galleria che promuove artisti emergenti',
                    tipo_arte: ['Arte contemporanea', 'Fotografia'],
                    url_immagine: 'https://example.com/gallery.jpg',
                    submitter_email: 'utente@example.com',
                    submission_date: new Date().toISOString(),
                    status: 'pending'
                },
                {
                    id: 'pending-2',
                    nome: 'Artigianato Moderno',
                    nome_jp: '現代工芸',
                    citta: 'Kyoto',
                    categoria: 'Design',
                    website: 'https://artigianato.example.com',
                    indirizzo: '45 Gion, Kyoto',
                    email: 'hello@artigianato.com',
                    telefono: '+81 75-123-4567',
                    descrizione: 'Spazio dedicato all\'artigianato contemporaneo',
                    tipo_arte: ['Design', 'Artigianato'],
                    url_immagine: 'https://example.com/artigianato.jpg',
                    submitter_email: 'designer@example.com',
                    submission_date: new Date().toISOString(),
                    status: 'pending'
                }
            ]);
            
            // Imposta l'ultimo ID utilizzato
            this.saveLastGalleryId(10000); // Inizia da un numero alto per evitare conflitti
        }
    }
    
    /**
     * Salva le gallerie originali nel localStorage
     * @param {Array} galleries - Array di gallerie originali
     */
    saveOriginalGalleries(galleries) {
        localStorage.setItem(this.STORAGE_KEYS.ORIGINAL_GALLERIES, JSON.stringify(galleries));
    }
    
    /**
     * Ottiene le gallerie originali dal localStorage
     * @returns {Array} Array di gallerie originali
     */
    getOriginalGalleries() {
        try {
            const galleries = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.ORIGINAL_GALLERIES)) || [];
            return galleries;
        } catch (error) {
            console.error('Error getting original galleries:', error);
            return [];
        }
    }
    
    /**
     * Salva le gallerie espanse nel localStorage
     * @param {Array} galleries - Array di gallerie espanse
     */
    saveExpandedGalleries(galleries) {
        localStorage.setItem(this.STORAGE_KEYS.EXPANDED_GALLERIES, JSON.stringify(galleries));
    }
    
    /**
     * Ottiene le gallerie espanse dal localStorage
     * @returns {Array} Array di gallerie espanse
     */
    getExpandedGalleries() {
        try {
            const galleries = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.EXPANDED_GALLERIES)) || [];
            return galleries;
        } catch (error) {
            console.error('Error getting expanded galleries:', error);
            return [];
        }
    }
    
    /**
     * Salva le richieste pendenti nel localStorage
     * @param {Array} galleries - Array di richieste pendenti
     */
    savePendingGalleries(galleries) {
        localStorage.setItem(this.STORAGE_KEYS.PENDING_GALLERIES, JSON.stringify(galleries));
    }
    
    /**
     * Ottiene le richieste pendenti dal localStorage
     * @returns {Array} Array di richieste pendenti
     */
    getPendingGalleries() {
        try {
            const galleries = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.PENDING_GALLERIES)) || [];
            return galleries;
        } catch (error) {
            console.error('Error getting pending galleries:', error);
            return [];
        }
    }
    
    /**
     * Salva l'ultimo ID di galleria utilizzato
     * @param {Number} id - L'ultimo ID utilizzato
     */
    saveLastGalleryId(id) {
        localStorage.setItem(this.STORAGE_KEYS.LAST_GALLERY_ID, id.toString());
    }
    
    /**
     * Ottiene l'ultimo ID di galleria utilizzato
     * @returns {Number} L'ultimo ID utilizzato
     */
    getLastGalleryId() {
        return parseInt(localStorage.getItem(this.STORAGE_KEYS.LAST_GALLERY_ID) || '10000', 10);
    }
    
    /**
     * Genera un nuovo ID univoco per una galleria
     * @returns {String} Nuovo ID univoco
     */
    generateNewGalleryId() {
        const lastId = this.getLastGalleryId();
        const newId = lastId + 1;
        this.saveLastGalleryId(newId);
        return `gallery-${newId}`;
    }
    
    /**
     * Genera un nuovo ID univoco per una richiesta pendente
     * @returns {String} Nuovo ID univoco
     */
    generateNewPendingId() {
        const lastId = this.getLastGalleryId();
        const newId = lastId + 1;
        this.saveLastGalleryId(newId);
        return `pending-${newId}`;
    }
    
    /**
     * Aggiunge una nuova richiesta pendente
     * @param {Object} gallery - Dati della galleria da aggiungere
     * @returns {Object} La nuova galleria con ID generato
     */
    addPendingGallery(gallery) {
        const pendingGalleries = this.getPendingGalleries();
        
        // Genera un nuovo ID univoco
        const newGallery = { 
            ...gallery,
            id: this.generateNewPendingId(),
            submission_date: new Date().toISOString(),
            status: 'pending'
        };
        
        // Aggiungi la nuova galleria all'array
        pendingGalleries.push(newGallery);
        
        // Salva l'array aggiornato
        this.savePendingGalleries(pendingGalleries);
        
        return newGallery;
    }
    
    /**
     * Approva una galleria pendente spostandola nel database appropriato
     * @param {String} id - ID della galleria pendente da approvare
     * @param {Boolean} isExpanded - Se la galleria deve essere aggiunta al database espanso
     * @returns {Object|null} La galleria approvata o null se non trovata
     */
    approveGallery(id, isExpanded = false) {
        const pendingGalleries = this.getPendingGalleries();
        const galleryIndex = pendingGalleries.findIndex(g => g.id === id);
        
        if (galleryIndex === -1) {
            console.error(`Gallery with ID ${id} not found in pending galleries`);
            return null;
        }
        
        // Rimuovi la galleria dalle richieste pendenti
        const [gallery] = pendingGalleries.splice(galleryIndex, 1);
        this.savePendingGalleries(pendingGalleries);
        
        // Converti nel formato corretto
        const approvedGallery = {
            id: isExpanded ? `expanded-${Date.now()}` : `original-${Date.now()}`,
            nome: gallery.nome,
            nome_jp: gallery.nome_jp || '',
            categoria: gallery.categoria,
            citta: gallery.citta,
            indirizzo: gallery.indirizzo,
            coordinate: gallery.coordinate || { lat: 35.6762, lng: 139.6503 }, // Default Tokyo
            website: gallery.website || gallery.sito_web || '',
            tipo_arte: gallery.tipo_arte || ['Arte Contemporanea'],
            descrizione: gallery.descrizione,
            anno_fondazione: gallery.anno_fondazione || null,
            orari: gallery.orari || 'Non specificato',
            contatti: gallery.contatti || gallery.email || 'Non specificato',
            verificato: true
        };
        
        // Aggiungi la galleria al database appropriato
        if (isExpanded) {
            const expandedGalleries = this.getExpandedGalleries();
            expandedGalleries.push(approvedGallery);
            this.saveExpandedGalleries(expandedGalleries);
        } else {
            const originalGalleries = this.getOriginalGalleries();
            originalGalleries.push(approvedGallery);
            this.saveOriginalGalleries(originalGalleries);
        }
        
        return approvedGallery;
    }
    
    /**
     * Elimina una galleria pendente
     * @param {String} id - ID della galleria pendente da eliminare
     * @returns {Boolean} true se l'eliminazione è avvenuta con successo
     */
    deletePendingGallery(id) {
        const pendingGalleries = this.getPendingGalleries();
        const newPendingGalleries = pendingGalleries.filter(g => g.id !== id);
        
        if (newPendingGalleries.length === pendingGalleries.length) {
            console.error(`Gallery with ID ${id} not found in pending galleries`);
            return false;
        }
        
        this.savePendingGalleries(newPendingGalleries);
        return true;
    }
    
    /**
     * Conta quante richieste pendenti ci sono
     * @returns {Number} Numero di richieste pendenti
     */
    countPendingGalleries() {
        return this.getPendingGalleries().length;
    }
}

// Crea un'istanza globale del database manager
const dbManager = new DatabaseManager();