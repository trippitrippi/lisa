/**
 * Gallery Images Manager per Lisa Word
 * Gestisce le immagini delle gallerie
 */
class GalleryImagesManager {
    constructor() {
        // Array di URL di immagini di gallerie d'arte
        this.galleryImages = [
            '/images/gallery-1.jpg',
            '/images/gallery-2.jpg',
            '/images/gallery-3.jpg',
            'https://images.unsplash.com/photo-1572947650440-e8a97ef053b2?w=500&auto=format',
            'https://images.unsplash.com/photo-1577720580479-7d839d829c73?w=500&auto=format',
            'https://images.unsplash.com/photo-1518998053901-5348d3961a04?w=500&auto=format',
            'https://images.unsplash.com/photo-1547826039-a657a042aeef?w=500&auto=format',
            'https://images.unsplash.com/photo-1577083288073-40892c0860a4?w=500&auto=format',
            'https://images.unsplash.com/photo-1617296539691-67feaadf389a?w=500&auto=format',
            'https://images.unsplash.com/photo-1605429523419-d828acb941d9?w=500&auto=format',
            'https://images.unsplash.com/photo-1594728613852-b844e35dab56?w=500&auto=format',
            'https://images.unsplash.com/photo-1578321272138-532694e4fae4?w=500&auto=format'
        ];
        
        // Cache per associare ID galleria a immagine
        this.imageCache = {};
    }
    
    /**
     * Ottiene un'immagine per una galleria basata sul suo ID
     * @param {String|Number} galleryId - ID della galleria
     * @param {String} customUrl - URL personalizzato (opzionale)
     * @returns {String} URL dell'immagine
     */
    getImageForGallery(galleryId, customUrl = null) {
        // Se è fornito un URL personalizzato, usalo
        if (customUrl && this.isValidImageUrl(customUrl)) {
            this.imageCache[galleryId] = customUrl;
            return customUrl;
        }
        
        // Se abbiamo già un'immagine per questa galleria nella cache, usala
        if (this.imageCache[galleryId]) {
            return this.imageCache[galleryId];
        }
        
        // Altrimenti, genera un'immagine basata sull'ID della galleria
        const imageIndex = this.getConsistentRandomIndex(galleryId, this.galleryImages.length);
        const imageUrl = this.galleryImages[imageIndex];
        
        // Salva nella cache
        this.imageCache[galleryId] = imageUrl;
        
        return imageUrl;
    }
    
    /**
     * Verifica se un URL è un'immagine valida
     * @param {String} url - URL da verificare
     * @returns {Boolean} true se l'URL sembra essere un'immagine valida
     */
    isValidImageUrl(url) {
        if (!url) return false;
        
        // Verifica se l'URL termina con un'estensione di immagine comune
        const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'];
        const hasImageExtension = imageExtensions.some(ext => url.toLowerCase().endsWith(ext));
        
        // Verifica se l'URL contiene domini comuni di hosting di immagini
        const imageHosts = ['unsplash.com', 'images.', 'img.', 'photos.', 'cdn.', 'storage.googleapis.com'];
        const hasImageHost = imageHosts.some(host => url.toLowerCase().includes(host));
        
        return hasImageExtension || hasImageHost;
    }
    
    /**
     * Genera un indice casuale ma consistente basato su una stringa
     * @param {String} str - Stringa da usare come seed
     * @param {Number} max - Valore massimo (esclusivo)
     * @returns {Number} Indice casuale tra 0 e max-1
     */
    getConsistentRandomIndex(str, max) {
        // Converti la stringa in un numero usando un semplice hash
        let hash = 0;
        for (let i = 0; i < str.toString().length; i++) {
            hash = ((hash << 5) - hash) + str.toString().charCodeAt(i);
            hash |= 0; // Converti a 32bit integer
        }
        
        // Usa il valore assoluto dell'hash come seed
        const seed = Math.abs(hash);
        
        // Genera un numero casuale tra 0 e max-1
        return seed % max;
    }
    
    /**
     * Ottiene un'immagine casuale dall'array
     * @returns {String} URL di un'immagine casuale
     */
    getRandomImage() {
        const randomIndex = Math.floor(Math.random() * this.galleryImages.length);
        return this.galleryImages[randomIndex];
    }
}

// Crea un'istanza globale del gestore di immagini
const imageManager = new GalleryImagesManager();