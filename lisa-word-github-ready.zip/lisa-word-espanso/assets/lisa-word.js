// Lisa Word - Main JavaScript File
// Database delle Gallerie d'Arte Giapponesi per Artisti Emergenti

// Sample gallery data (based on original site structure)
const galleriesData = [
    {
        id: 1,
        nome: "1/M (Ichiemu) - Musashino Art University",
        nome_jp: "1/M（イチエム）- 武蔵野美術大学",
        categoria: "Università",
        citta: "Tokyo",
        prefettura: "Tokyo",
        indirizzo: "1-736 Ogawa-cho, Kodaira-shi, Tokyo 187-8505",
        telefono: "+81-42-342-6000",
        email: "info@musabi.ac.jp",
        sito_web: "https://www.musabi.ac.jp",
        url_immagine: "/images/galleries/gallery-1.jpg",
        tipo_arte: ["Arte sperimentale", "Progetti universitari"],
        target_artisti: "Studenti universitari",
        descrizione: "Spazio sperimentale universitario per progetti innovativi di studenti e ricercatori.",
        anno_fondazione: 2010,
        coordinate: { lat: 35.7276, lng: 139.4813 }
    },
    {
        id: 2,
        nome: "Ameya-Yokocho Young Gallery",
        nome_jp: "アメヤ横丁ヤングギャラリー",
        categoria: "Galleria Indipendente",
        citta: "Tokyo",
        prefettura: "Tokyo",
        indirizzo: "4-7-8 Ueno, Taito-ku, Tokyo 110-0005",
        telefono: "+81-3-3832-5053",
        email: "info@ameyoko-young.jp",
        sito_web: "https://ameyoko-young.jp",
        url_immagine: "/images/galleries/gallery-2.jpg",
        tipo_arte: ["Street art", "Illustrazione", "Arte popolare"],
        target_artisti: "Giovani artisti locali",
        descrizione: "Piccola galleria nel mercato Ameya-Yokocho che supporta giovani artisti emergenti.",
        anno_fondazione: 2019,
        coordinate: { lat: 35.7070, lng: 139.7751 }
    },
    {
        id: 3,
        nome: "Tokyo Arts and Space (TOKAS)",
        nome_jp: "東京都現代美術館",
        categoria: "Artisti Emergenti",
        citta: "Tokyo",
        prefettura: "Tokyo",
        indirizzo: "3-2-11 Nippori, Arakawa-ku, Tokyo 116-0014",
        telefono: "+81-3-5830-4406",
        email: "info@tokyoartsandspace.jp",
        sito_web: "https://www.tokyoartsandspace.jp",
        url_immagine: "/images/galleries/gallery-3.jpg",
        tipo_arte: ["Arte contemporanea", "Installazioni", "Performance"],
        target_artisti: "Artisti emergenti internazionali",
        descrizione: "Spazio dedicato alla promozione di artisti emergenti con programmi di residenza.",
        anno_fondazione: 2001,
        coordinate: { lat: 35.7278, lng: 139.7701 }
    }
];

// Statistical data for charts
const statisticsData = {
    cities: {
        labels: ['Tokyo', 'Osaka', 'Kyoto', 'Kobe', 'Nagoya', 'Fukuoka', 'Sapporo', 'Sendai'],
        data: [76, 28, 22, 18, 15, 12, 8, 6]
    },
    categories: {
        labels: ['Artisti Emergenti', 'undefined', 'Università', 'Student-Run', 'Galleria Indipendente', 'Artist-Run Space'],
        data: [25, 25, 21, 9, 8, 7]
    },
    artTypes: {
        labels: ['Arte contemporanea', 'Installazioni', 'Design', 'Arte sperimentale', 'Fotografia', 'Pittura', 'Scultura', 'Performance', 'Arte digitale', 'Street art'],
        data: [58, 45, 38, 32, 28, 25, 22, 18, 15, 12]
    },
    timeline: {
        labels: ['1880-1900', '1901-1920', '1921-1940', '1941-1960', '1961-1980', '1981-2000', '2001-2010', '2011-2022'],
        data: [2, 3, 5, 8, 12, 18, 25, 38]
    }
};

// Google Maps instance
let map;
let markers = [];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    showSection('home');
});

function initializeApp() {
    console.log('Lisa Word - Initializing application...');
    
    // Set up mobile menu
    setupMobileMenu();
    
    // Initialize gallery grid
    displayGalleries(galleriesData);
    
    // Initialize statistics charts
    initializeCharts();
    
    console.log('Application initialized successfully');
}

function setupEventListeners() {
    // Navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                const section = this.getAttribute('href').substring(1);
                showSection(section);
            }
        });
    });

    // Contact form - FIX per il problema identificato
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactSubmit);
        
        // Assicuriamo che tutti i campi siano accessibili
        const nameField = document.getElementById('name');
        const emailField = document.getElementById('email');
        if (nameField) nameField.style.display = 'block';
        if (emailField) emailField.style.display = 'block';
    }

    // Add gallery form
    const addGalleryForm = document.getElementById('addGalleryForm');
    if (addGalleryForm) {
        addGalleryForm.addEventListener('submit', handleAddGallerySubmit);
    }

    // Admin login form
    const adminLoginForm = document.getElementById('adminLoginForm');
    if (adminLoginForm) {
        adminLoginForm.addEventListener('submit', handleAdminLogin);
    }

    // Filter controls
    const filterControls = ['cityFilter', 'categoryFilter', 'artTypeFilter'];
    filterControls.forEach(filterId => {
        const filter = document.getElementById(filterId);
        if (filter) {
            filter.addEventListener('change', applyFilters);
        }
    });
}

function setupMobileMenu() {
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', function() {
            // Toggle mobile menu (implementation depends on design)
            console.log('Mobile menu toggled');
        });
    }
}

function showSection(sectionId) {
    // Hide all sections
    const sections = ['home', 'gallerie', 'mappa', 'statistiche', 'contatti', 'aggiungi', 'admin'];
    sections.forEach(id => {
        const section = document.getElementById(id);
        if (section) {
            if (id === sectionId) {
                section.classList.remove('hidden');
                // Special initialization for certain sections
                if (id === 'mappa') {
                    setTimeout(initializeMap, 100);
                } else if (id === 'statistiche') {
                    setTimeout(updateCharts, 100);
                }
            } else {
                section.classList.add('hidden');
            }
        }
    });

    // Update URL hash
    window.location.hash = sectionId;
    
    // Scroll to top
    window.scrollTo(0, 0);
}

function displayGalleries(galleries) {
    const grid = document.getElementById('galleryGrid');
    if (!grid) return;

    grid.innerHTML = '';

    galleries.forEach(gallery => {
        const card = createGalleryCard(gallery);
        grid.appendChild(card);
    });
}

function createGalleryCard(gallery) {
    const card = document.createElement('div');
    card.className = 'bg-white rounded-lg shadow card-hover overflow-hidden';
    
    card.innerHTML = `
        <div class="relative">
            <img src="${gallery.url_immagine}" alt="${gallery.nome}" 
                 class="w-full h-48 object-cover" 
                 onerror="this.src='/images/placeholder-gallery.jpg'">
            <div class="absolute top-4 left-4">
                <span class="bg-blue-600 text-white px-2 py-1 rounded text-sm">${gallery.categoria}</span>
            </div>
        </div>
        <div class="p-6">
            <h3 class="text-lg font-semibold mb-2">${gallery.nome}</h3>
            <p class="text-gray-600 text-sm mb-2">${gallery.nome_jp}</p>
            <p class="text-gray-600 mb-2">${gallery.citta}</p>
            <p class="text-gray-700 mb-4 text-sm">${gallery.descrizione}</p>
            <div class="flex flex-wrap gap-1 mb-4">
                ${gallery.tipo_arte.map(tipo => 
                    `<span class="bg-gray-200 text-gray-700 px-2 py-1 rounded text-xs">${tipo}</span>`
                ).join('')}
            </div>
            <div class="flex gap-2">
                <button onclick="showGalleryDetails(${gallery.id})" 
                        class="bg-blue-600 text-white px-4 py-2 rounded text-sm hover:bg-blue-700">
                    Dettagli
                </button>
                ${gallery.sito_web ? 
                    `<a href="${gallery.sito_web}" target="_blank" 
                        class="bg-gray-600 text-white px-4 py-2 rounded text-sm hover:bg-gray-700">
                        Visita Sito
                    </a>` : 
                    `<span class="bg-gray-300 text-gray-500 px-4 py-2 rounded text-sm">
                        Sito non disponibile
                    </span>`
                }
            </div>
        </div>
    `;

    return card;
}

function applyFilters() {
    const cityFilter = document.getElementById('cityFilter').value;
    const categoryFilter = document.getElementById('categoryFilter').value;
    const artTypeFilter = document.getElementById('artTypeFilter').value;

    let filteredGalleries = galleriesData.filter(gallery => {
        let matchCity = !cityFilter || gallery.citta === cityFilter;
        let matchCategory = !categoryFilter || gallery.categoria === categoryFilter;
        let matchArtType = !artTypeFilter || gallery.tipo_arte.includes(artTypeFilter);
        
        return matchCity && matchCategory && matchArtType;
    });

    displayGalleries(filteredGalleries);
}

function showGalleryDetails(galleryId) {
    const gallery = galleriesData.find(g => g.id === galleryId);
    if (!gallery) return;

    alert(`Dettagli di ${gallery.nome}:\n\nCategoria: ${gallery.categoria}\nCittà: ${gallery.citta}\nDescrizione: ${gallery.descrizione}\n\nContatti:\nTelefono: ${gallery.telefono}\nEmail: ${gallery.email}\nSito: ${gallery.sito_web || 'Non disponibile'}`);
}

function initializeMap() {
    if (typeof google === 'undefined') {
        console.error('Google Maps API non caricata');
        return;
    }

    const mapElement = document.getElementById('map');
    if (!mapElement) return;

    // Center on Tokyo
    const tokyoCenter = { lat: 35.6812, lng: 139.7671 };

    map = new google.maps.Map(mapElement, {
        zoom: 12,
        center: tokyoCenter,
        mapTypeId: 'hybrid'
    });

    // Clear existing markers
    markers.forEach(marker => marker.setMap(null));
    markers = [];

    // Add markers for galleries
    galleriesData.forEach((gallery, index) => {
        const marker = new google.maps.Marker({
            position: gallery.coordinate,
            map: map,
            title: gallery.nome,
            icon: {
                url: '/images/map-marker.png',
                scaledSize: new google.maps.Size(40, 40)
            }
        });

        const infoWindow = new google.maps.InfoWindow({
            content: `
                <div style="padding: 10px;">
                    <h3 style="margin: 0 0 5px 0; font-size: 16px;">${gallery.nome}</h3>
                    <p style="margin: 0 0 5px 0; color: #666;">${gallery.indirizzo}</p>
                    <p style="margin: 0;"><a href="#" onclick="showGalleryDetails(${gallery.id})" style="color: #1e40af;">Visualizza dettagli</a></p>
                </div>
            `
        });

        marker.addListener('click', () => {
            infoWindow.open(map, marker);
        });

        markers.push(marker);
    });
}

function initializeCharts() {
    // Charts will be created when statistics section is shown
    console.log('Charts initialized');
}

function updateCharts() {
    if (typeof Chart === 'undefined') {
        console.error('Chart.js non caricato');
        return;
    }

    // City distribution chart
    const cityCtx = document.getElementById('cityChart');
    if (cityCtx) {
        new Chart(cityCtx, {
            type: 'bar',
            data: {
                labels: statisticsData.cities.labels,
                datasets: [{
                    label: 'Numero Gallerie',
                    data: statisticsData.cities.data,
                    backgroundColor: 'rgba(59, 130, 246, 0.6)',
                    borderColor: 'rgba(59, 130, 246, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    // Category distribution chart
    const categoryCtx = document.getElementById('categoryChart');
    if (categoryCtx) {
        new Chart(categoryCtx, {
            type: 'pie',
            data: {
                labels: statisticsData.categories.labels,
                datasets: [{
                    data: statisticsData.categories.data,
                    backgroundColor: [
                        'rgba(59, 130, 246, 0.8)',
                        'rgba(16, 185, 129, 0.8)',
                        'rgba(245, 158, 11, 0.8)',
                        'rgba(239, 68, 68, 0.8)',
                        'rgba(139, 92, 246, 0.8)',
                        'rgba(236, 72, 153, 0.8)'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }

    // Art types chart
    const artTypeCtx = document.getElementById('artTypeChart');
    if (artTypeCtx) {
        new Chart(artTypeCtx, {
            type: 'bar',
            data: {
                labels: statisticsData.artTypes.labels,
                datasets: [{
                    label: 'Numero Gallerie',
                    data: statisticsData.artTypes.data,
                    backgroundColor: 'rgba(16, 185, 129, 0.6)',
                    borderColor: 'rgba(16, 185, 129, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                indexAxis: 'y',
                scales: {
                    x: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    // Timeline chart
    const timelineCtx = document.getElementById('timelineChart');
    if (timelineCtx) {
        new Chart(timelineCtx, {
            type: 'line',
            data: {
                labels: statisticsData.timeline.labels,
                datasets: [{
                    label: 'Gallerie Fondate',
                    data: statisticsData.timeline.data,
                    borderColor: 'rgba(139, 92, 246, 1)',
                    backgroundColor: 'rgba(139, 92, 246, 0.1)',
                    tension: 0.1,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
}

// FIX per il problema del form contatti identificato nell'analisi
function handleContactSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    
    // Validazione migliorata per assicurare che tutti i campi siano accessibili
    const name = formData.get('name');
    const email = formData.get('email');
    const subject = formData.get('subject');
    const message = formData.get('message');
    
    if (!name || !email || !subject || !message) {
        alert('Errore: Tutti i campi sono obbligatori. Se non riesci a vedere alcuni campi, ricarica la pagina.');
        return;
    }
    
    const data = { name, email, subject, message };
    console.log('Contact form submitted:', data);
    
    // Simulazione invio con miglioramento per il problema identificato
    alert('Messaggio inviato con successo! Ti risponderemo entro 48 ore lavorative al seguente indirizzo: carlogrecoph@gmail.com');
    e.target.reset();
}

function handleAddGallerySubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    // Validazione checkbox privacy
    if (!data.privacyConsent) {
        alert('È necessario accettare il trattamento dei dati per procedere.');
        return;
    }

    console.log('Gallery submission:', data);
    
    // Simulate submission
    alert('Richiesta di aggiunta galleria inviata con successo! Verrà esaminata dal nostro team e aggiunta al database dopo approvazione.');
    e.target.reset();
}

function handleAdminLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('adminEmail').value;
    const password = document.getElementById('adminPassword').value;

    console.log('Admin login attempt:', email);
    
    // Simulate login with security improvement
    if (!email || !password) {
        alert('Inserisci email e password.');
        return;
    }
    
    alert('Area amministrativa - Le credenziali verranno verificate dal sistema. Accesso limitato agli amministratori autorizzati.');
}

// Handle browser back/forward
window.addEventListener('hashchange', function() {
    const hash = window.location.hash.substring(1);
    if (hash) {
        showSection(hash);
    }
});

// Set initial section based on URL hash
window.addEventListener('load', function() {
    const hash = window.location.hash.substring(1);
    if (hash) {
        showSection(hash);
    }
});

// Export functions for global access
window.showSection = showSection;
window.showGalleryDetails = showGalleryDetails;
window.applyFilters = applyFilters;