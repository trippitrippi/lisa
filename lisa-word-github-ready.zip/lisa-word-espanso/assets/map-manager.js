// Lisa Word Map Manager
// Gestisce la mappa interattiva delle gallerie d'arte giapponesi

class MapManager {
  constructor() {
    this.map = null;
    this.markers = [];
    this.infoWindows = [];
    this.originalGalleryMarkers = [];
    this.expandedGalleryMarkers = [];
    this.clusterer = null;
    this.bounds = null;
    this.defaultCenter = { lat: 35.6762, lng: 139.6503 }; // Tokyo
    this.initialized = false;
  }

  // Inizializza la mappa
  async initialize(elementId, originalGalleries, expandedGalleries) {
    if (typeof google === 'undefined') {
      console.error('Google Maps API non caricata');
      this.showMapError(elementId);
      return;
    }

    const mapElement = document.getElementById(elementId);
    if (!mapElement) {
      console.error(`Elemento mappa con ID ${elementId} non trovato`);
      return;
    }

    this.bounds = new google.maps.LatLngBounds();

    // Crea la mappa
    this.map = new google.maps.Map(mapElement, {
      zoom: 6,
      center: this.defaultCenter,
      mapTypeId: 'terrain',
      mapTypeControl: true,
      mapTypeControlOptions: {
        style: google.maps.MapTypeControlStyle.DROPDOWN_MENU,
        position: google.maps.ControlPosition.TOP_RIGHT
      },
      fullscreenControl: true,
      streetViewControl: true,
      zoomControl: true,
      zoomControlOptions: {
        position: google.maps.ControlPosition.RIGHT_CENTER
      }
    });

    // Aggiungi i controlli personalizzati
    this.addCustomControls(mapElement);

    // Aggiungi i marker
    await this.addGalleryMarkers(originalGalleries, false);
    await this.addGalleryMarkers(expandedGalleries, true);

    // Adatta la mappa ai marker
    if (this.markers.length > 0) {
      this.map.fitBounds(this.bounds);
      
      // Se lo zoom è troppo alto (troppo vicino), limitalo
      const listener = google.maps.event.addListener(this.map, 'idle', () => {
        if (this.map.getZoom() > 15) {
          this.map.setZoom(15);
        }
        google.maps.event.removeListener(listener);
      });
    }

    this.initialized = true;
    console.log('Mappa inizializzata con successo');
  }

  // Aggiungi controlli personalizzati alla mappa
  addCustomControls(mapElement) {
    // Controlli layer
    const layerControlDiv = document.createElement('div');
    layerControlDiv.className = 'bg-white rounded shadow-md m-2 p-2';
    layerControlDiv.style.position = 'absolute';
    layerControlDiv.style.top = '10px';
    layerControlDiv.style.left = '10px';
    layerControlDiv.style.zIndex = '1';
    
    layerControlDiv.innerHTML = `
      <div class="text-sm font-semibold mb-2 px-1">Filtri Mappa</div>
      <div class="flex flex-col space-y-2">
        <label class="flex items-center cursor-pointer">
          <input type="checkbox" id="show-original-galleries" checked class="mr-2">
          <span class="text-sm">Gallerie Originali</span>
        </label>
        <label class="flex items-center cursor-pointer">
          <input type="checkbox" id="show-expanded-galleries" checked class="mr-2">
          <span class="text-sm">Gallerie Espanse</span>
        </label>
      </div>
      <div class="mt-2 pt-2 border-t border-gray-200">
        <button id="reset-map-view" class="w-full bg-blue-600 text-white text-xs py-1 px-2 rounded hover:bg-blue-700">
          Reset Vista
        </button>
      </div>
    `;
    
    this.map.controls[google.maps.ControlPosition.TOP_LEFT].push(layerControlDiv);
    
    // Aggiungi event listener ai controlli
    setTimeout(() => {
      document.getElementById('show-original-galleries').addEventListener('change', () => this.toggleMarkerGroup('original'));
      document.getElementById('show-expanded-galleries').addEventListener('change', () => this.toggleMarkerGroup('expanded'));
      document.getElementById('reset-map-view').addEventListener('click', () => this.resetMapView());
    }, 100);
  }

  // Mostra un errore nella mappa
  showMapError(elementId) {
    const mapElement = document.getElementById(elementId);
    if (!mapElement) return;
    
    mapElement.innerHTML = `
      <div class="flex flex-col items-center justify-center h-full bg-gray-100 p-8 text-center">
        <svg class="w-16 h-16 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
        </svg>
        <h3 class="text-xl font-medium text-gray-900 mb-2">Impossibile caricare la mappa</h3>
        <p class="text-gray-600 mb-4">Si è verificato un errore durante il caricamento di Google Maps.</p>
        <button onclick="window.location.reload()" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
          Riprova
        </button>
      </div>
    `;
  }

  // Aggiungi marker per le gallerie
  async addGalleryMarkers(galleries, isExpanded) {
    if (!galleries || !Array.isArray(galleries)) return;
    
    const defaultImage = `/images/gallery-${Math.floor(Math.random() * 3) + 1}.jpg`;
    const markerIcon = {
      url: isExpanded ? '/images/map-marker-expanded.png' : '/images/map-marker.png',
      scaledSize: new google.maps.Size(32, 32),
      origin: new google.maps.Point(0, 0),
      anchor: new google.maps.Point(16, 32)
    };
    
    for (const gallery of galleries) {
      // Verifica che la galleria abbia coordinate valide
      if (!gallery.coordinate || !gallery.coordinate.lat || !gallery.coordinate.lng) {
        continue;
      }
      
      const position = new google.maps.LatLng(
        gallery.coordinate.lat,
        gallery.coordinate.lng
      );
      
      // Estendi i limiti della mappa
      this.bounds.extend(position);
      
      // Crea il marker
      const marker = new google.maps.Marker({
        position: position,
        map: this.map,
        title: gallery.nome || 'Galleria senza nome',
        icon: markerIcon,
        animation: google.maps.Animation.DROP
      });
      
      // Crea la finestra info
      const infoWindow = new google.maps.InfoWindow({
        content: this.createInfoWindowContent(gallery, isExpanded, defaultImage)
      });
      
      // Aggiungi evento click al marker
      marker.addListener('click', () => {
        // Chiudi tutte le finestre info aperte
        this.infoWindows.forEach(iw => iw.close());
        
        // Apri questa finestra info
        infoWindow.open(this.map, marker);
      });
      
      // Aggiungi il marker all'array appropriato
      this.markers.push(marker);
      this.infoWindows.push(infoWindow);
      
      if (isExpanded) {
        this.expandedGalleryMarkers.push(marker);
      } else {
        this.originalGalleryMarkers.push(marker);
      }
    }
  }

  // Crea il contenuto HTML per la finestra info
  createInfoWindowContent(gallery, isExpanded, defaultImage) {
    const imageUrl = gallery.url_immagine || gallery.image_url || defaultImage;
    const website = gallery.website || gallery.sito_web || '';
    const nome = gallery.nome || 'Galleria senza nome';
    const nomeJp = gallery.nome_jp || '';
    const citta = gallery.citta || gallery.città || '';
    const indirizzo = gallery.indirizzo || '';
    const descrizione = gallery.descrizione || 'Nessuna descrizione disponibile';
    
    // Crea classe CSS in base al tipo di galleria
    const typeClass = isExpanded ? 'border-yellow-500' : 'border-blue-500';
    const typeLabel = isExpanded ? 'Nuova Galleria' : 'Galleria Originale';
    const typeColor = isExpanded ? 'bg-yellow-100 text-yellow-800' : 'bg-blue-100 text-blue-800';
    
    return `
      <div class="max-w-xs p-0 overflow-hidden">
        <div class="relative">
          <img src="${imageUrl}" alt="${nome}" class="w-full h-36 object-cover" onerror="this.src='${defaultImage}'">
          <div class="absolute top-2 right-2">
            <span class="text-xs font-semibold ${typeColor} px-2 py-1 rounded-full">${typeLabel}</span>
          </div>
        </div>
        <div class="p-3 border-t-4 ${typeClass}">
          <h3 class="text-lg font-bold text-gray-900 mb-1">${nome}</h3>
          ${nomeJp ? `<p class="text-sm text-gray-600 mb-2">${nomeJp}</p>` : ''}
          <p class="text-sm text-gray-700 mb-2">${citta}${indirizzo ? `, ${indirizzo}` : ''}</p>
          <p class="text-xs text-gray-600 mb-3 line-clamp-2">${descrizione}</p>
          <div class="flex justify-between items-center">
            <button onclick="showGalleryDetails(${gallery.id}, ${isExpanded})" class="text-xs bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700">
              Dettagli
            </button>
            ${website ? `
              <a href="${website}" target="_blank" class="text-xs bg-gray-600 text-white px-3 py-1 rounded hover:bg-gray-700">
                Visita Sito
              </a>
            ` : ''}
          </div>
        </div>
      </div>
    `;
  }

  // Mostra/nascondi un gruppo di marker
  toggleMarkerGroup(group) {
    const markers = group === 'original' ? this.originalGalleryMarkers : this.expandedGalleryMarkers;
    const visible = group === 'original' 
      ? document.getElementById('show-original-galleries').checked
      : document.getElementById('show-expanded-galleries').checked;
    
    markers.forEach(marker => {
      marker.setVisible(visible);
    });
  }

  // Resetta la vista della mappa
  resetMapView() {
    if (this.markers.length > 0) {
      // Ricrea i bounds con tutti i marker visibili
      const newBounds = new google.maps.LatLngBounds();
      this.markers.forEach(marker => {
        if (marker.getVisible()) {
          newBounds.extend(marker.getPosition());
        }
      });
      
      if (!newBounds.isEmpty()) {
        this.map.fitBounds(newBounds);
      } else {
        this.map.setCenter(this.defaultCenter);
        this.map.setZoom(6);
      }
    } else {
      this.map.setCenter(this.defaultCenter);
      this.map.setZoom(6);
    }
  }
  
  // Aggiorna la mappa con nuovi dati
  async update(originalGalleries, expandedGalleries) {
    // Rimuovi tutti i marker esistenti
    this.markers.forEach(marker => marker.setMap(null));
    this.markers = [];
    this.originalGalleryMarkers = [];
    this.expandedGalleryMarkers = [];
    this.infoWindows = [];
    
    // Resetta i bounds
    this.bounds = new google.maps.LatLngBounds();
    
    // Aggiungi i nuovi marker
    await this.addGalleryMarkers(originalGalleries, false);
    await this.addGalleryMarkers(expandedGalleries, true);
    
    // Adatta la mappa ai marker
    this.resetMapView();
  }
}

// Crea un'istanza globale del gestore della mappa
window.mapManager = new MapManager();