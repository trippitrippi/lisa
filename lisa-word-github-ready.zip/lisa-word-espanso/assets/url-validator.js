// URL Validator for Lisa Word Galleries
// Questo script si occupa della verifica degli URL e della validazione delle gallerie

// Lista di URL già verificati (cache)
const verifiedUrls = new Map();
const brokenUrls = new Set();

// Funzione per verificare un URL
async function checkUrl(url) {
  if (!url) return false;
  
  // Se l'URL è già stato verificato, usa il risultato in cache
  if (verifiedUrls.has(url)) {
    return verifiedUrls.get(url);
  }
  
  // Se l'URL è già stato verificato come non funzionante, non ripetere il controllo
  if (brokenUrls.has(url)) {
    return false;
  }
  
  try {
    // In un'implementazione reale, qui chiameremmo un servizio backend
    // che verifica l'URL. Poiché siamo in un ambiente client-side simulato,
    // facciamo una simulazione di verifica
    
    // Verifica che l'URL inizi con http:// o https://
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      brokenUrls.add(url);
      return false;
    }
    
    // Simuliamo la verifica con alcuni URL che sappiamo essere non validi
    const invalidDomains = [
      'example.com',
      'test.com',
      'nonfunziona.jp',
      'galleryerror.co.jp',
      'site-down.jp',
      'sitononesistente.com'
    ];
    
    const urlDomain = new URL(url).hostname;
    const isInvalid = invalidDomains.some(domain => urlDomain.includes(domain));
    
    if (isInvalid) {
      brokenUrls.add(url);
      return false;
    }
    
    // Simuliamo un controllo casuale per alcuni URL (10% di probabilità di non funzionare)
    // ma solo per domini non comuni
    const commonDomains = ['google.com', 'artsy.net', 'tokyo-art.info', 'facebook.com', 'twitter.com', 'instagram.com'];
    if (!commonDomains.some(domain => urlDomain.includes(domain)) && Math.random() < 0.1) {
      brokenUrls.add(url);
      return false;
    }
    
    // Se arriviamo qui, l'URL è valido
    verifiedUrls.set(url, true);
    return true;
  } catch (error) {
    // Se c'è un errore, l'URL non è valido
    console.error(`Errore nella verifica dell'URL ${url}:`, error);
    brokenUrls.add(url);
    return false;
  }
}

// Funzione per verificare tutti gli URL delle gallerie
async function verifyGalleryUrls(galleries) {
  const verificationResults = [];
  const maxConcurrent = 5; // Massimo numero di verifiche concorrenti
  
  // Dividi le gallerie in batch per evitare troppe richieste simultanee
  for (let i = 0; i < galleries.length; i += maxConcurrent) {
    const batch = galleries.slice(i, i + maxConcurrent);
    
    // Verifica gli URL in questo batch in parallelo
    const batchPromises = batch.map(async gallery => {
      const url = gallery.website || gallery.sito_web;
      if (!url) return { gallery, isValid: false };
      
      const isValid = await checkUrl(url);
      return { gallery, isValid };
    });
    
    // Attendi che tutte le verifiche di questo batch siano completate
    const batchResults = await Promise.all(batchPromises);
    verificationResults.push(...batchResults);
    
    // Breve pausa tra un batch e l'altro per non sovraccaricare il sistema
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  
  return verificationResults;
}

// Funzione per aggiornare lo stato di verifica delle gallerie
async function updateGalleryVerificationStatus(galleries) {
  const results = await verifyGalleryUrls(galleries);
  
  // Aggiorna lo stato di verifica di ogni galleria
  results.forEach(({ gallery, isValid }) => {
    gallery.verificato = isValid;
  });
  
  // Restituisci le statistiche
  const verifiedCount = results.filter(r => r.isValid).length;
  const brokenCount = results.filter(r => !r.isValid).length;
  
  return {
    total: galleries.length,
    verified: verifiedCount,
    broken: brokenCount,
    results
  };
}

// Funzione per filtrare le gallerie con URL non funzionanti
function filterBrokenGalleries(galleries) {
  return galleries.filter(gallery => {
    const url = gallery.website || gallery.sito_web;
    return !url || !brokenUrls.has(url);
  });
}

// Esporta le funzioni
window.checkUrl = checkUrl;
window.verifyGalleryUrls = verifyGalleryUrls;
window.updateGalleryVerificationStatus = updateGalleryVerificationStatus;
window.filterBrokenGalleries = filterBrokenGalleries;